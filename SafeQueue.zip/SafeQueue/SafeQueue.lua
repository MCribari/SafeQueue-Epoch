local ENTER_BATTLE = ENTER_BATTLE

local GetBattlefieldPortExpiration = GetBattlefieldPortExpiration

StaticPopupDialogs["CONFIRM_BATTLEFIELD_ENTRY"].hideOnEscape = false

StaticPopupDialogs["CONFIRM_BATTLEFIELD_ENTRY"].OnShow = function(self)
	self.button2:Disable()
end

StaticPopupDialogs["CONFIRM_BATTLEFIELD_ENTRY"].OnUpdate = function(self)
	self.button1:SetFormattedText("%s (%d)", ENTER_BATTLE, GetBattlefieldPortExpiration(self.data))
end